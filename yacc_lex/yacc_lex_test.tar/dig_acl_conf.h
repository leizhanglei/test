#ifndef _H_DIG_ACL_CONF_H_
#define _H_DIG_ACL_CONF_H_

#include <stdio.h>
#include <errno.h>

#include <stdint.h>
#include <string.h>
#include "dig_error.h"
#include "dig_utils.h"

/*
 *acl conf interface
 */

#define CONF_LEN    255

typedef struct acl_conf_elem acl_conf_elem_t; 
struct acl_conf_elem {
    char ip[CONF_LEN];
    uint32_t mask;
    struct acl_conf_elem *next;
};

typedef struct acl_conf acl_conf_t;
struct acl_conf {
    char name[CONF_LEN];
    acl_conf_elem_t *acls;
    acl_conf_elem_t *iter_ptr;
    struct acl_conf *next;
};

acl_conf_t*
acl_conf_create(const char *name);

void
acl_conf_destroy(acl_conf_t* conf);

result_t
acl_conf_insert_acl(acl_conf_t *acls, const char *str);

result_t 
acl_conf_iter_begin(acl_conf_t *acls);

const char*
acl_conf_iter_next(acl_conf_t *acls, uint32_t *mask);

typedef struct acl_conf_mgr {
    acl_conf_t *list;
    acl_conf_t *iter_ptr;
} acl_conf_mgr_t; 

acl_conf_mgr_t*
acl_conf_mgr_create();

void
acl_conf_mgr_destroy(acl_conf_mgr_t* mgr);

const acl_conf_t*
acl_conf_mgr_find_acl_by_name(acl_conf_mgr_t *mgr, const char *acl_name);

result_t
acl_conf_mgr_insert_acl_conf(acl_conf_mgr_t *mgr, acl_conf_t *conf);

result_t 
acl_conf_mgr_iter_begin(acl_conf_mgr_t *mgr);

acl_conf_t *
acl_conf_mgr_iter_next(acl_conf_mgr_t *mgr);

/*
 * view interface
 */
typedef struct view_acl view_acl_t;
struct view_acl {
    char acl_name[CONF_LEN];
    struct view_acl *next;
};

view_acl_t *
view_acl_create(const char* acl_name);

typedef struct view_conf view_conf_t;
struct view_conf {
    char view_name[CONF_LEN];
    uint32_t view_id;
    struct view_acl *acls;
    struct view_acl *iter_ptr;
    struct view_conf *next;
};

view_conf_t *
view_conf_create(const char* view_name);

void
view_conf_destroy(view_conf_t* conf);

result_t
view_conf_set_view_id(view_conf_t* conf, uint32_t view_id);

result_t
view_conf_insert_acl(view_conf_t *conf, const char *acl_name);

result_t
view_conf_iter_begin(view_conf_t *conf);

const char *
view_conf_iter_next(view_conf_t *conf);

typedef struct view_conf_mgr {
    view_conf_t *views;
    view_conf_t *iter_ptr;
} view_conf_mgr_t;

view_conf_mgr_t *
view_conf_mgr_create();

void
view_conf_mgr_destroy(view_conf_mgr_t* mgr);

result_t 
view_conf_mgr_insert_view(view_conf_mgr_t *mgr, view_conf_t *view);

result_t
view_conf_mgr_iter_begin(view_conf_mgr_t *mgr);

view_conf_t *
view_conf_mgr_iter_next(view_conf_mgr_t *mgr);

/*
 * smart parse mgr
 */
typedef struct smartdns_conf smartdns_conf_t;
struct smartdns_conf {
    char name[CONF_LEN];
    acl_conf_mgr_t *acls;
    view_conf_mgr_t *views;
    struct smartdns_conf *next;
};

smartdns_conf_t *
smartdns_conf_create(const char *name);

void
smartdns_conf_destroy(smartdns_conf_t* conf);

result_t 
smartdns_conf_set_acls(smartdns_conf_t *conf, acl_conf_mgr_t *acls);

acl_conf_mgr_t *
smartdns_conf_get_acls(smartdns_conf_t *conf);

result_t
smartdns_conf_set_views(smartdns_conf_t *conf, view_conf_mgr_t *views);

view_conf_mgr_t *
smartdns_conf_get_views(smartdns_conf_t *conf);

typedef struct smartdns_conf_mgr smartdns_conf_mgr_t;
struct smartdns_conf_mgr {
    smartdns_conf_t *confs;
    smartdns_conf_t *iter_ptr;
};

smartdns_conf_mgr_t *
smartdns_conf_mgr_create();

void
smartdns_conf_mgr_destroy(smartdns_conf_mgr_t* mgr);

result_t
smartdns_conf_mgr_insert_smartdns_conf(smartdns_conf_mgr_t *mgr, smartdns_conf_t *conf);

result_t
smartdns_conf_mgr_iter_begin(smartdns_conf_mgr_t *mgr);

smartdns_conf_t *
smartdns_conf_mgr_iter_next(smartdns_conf_mgr_t *mgr);

#endif  /*_H_DIG_ACL_CONF_H_*/

