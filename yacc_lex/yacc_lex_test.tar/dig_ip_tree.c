#include "dig_utils.h"
#include "dig_ip_tree.h"

typedef struct ip_node   ip_node_t;

struct ip_node 
{
    ip_node_t   *right;
    ip_node_t   *left;
    ip_node_t   *parent;
    void        *value;
};

struct ip_tree 
{
    ip_node_t   *root;
    ip_node_t   *free;
    value_del_function  value_delete_func;
};

#define NGX_RADIX_NO_VALUE  (void *)NULL
#define NODE_IS_EMPTY(node) (NGX_RADIX_NO_VALUE == ((node)->value))


static void *       ip_tree_alloc(ip_tree_t *tree);
static void         ip_node_delete(ip_node_t *node, value_del_function del_func);
//static ip_node_t *  ip_tree_get_leftest_node(ip_tree_t *tree);
//static ip_node_t *  ip_node_next(ip_node_t *node);
static void         ip_tree_walk_helper(ip_node_t *node, walk_function walk_func, void *arg);


ip_tree_t *
ip_tree_create(value_del_function del_func)
{
    ip_tree_t    *tree = NULL;
    DIG_MALLOC(tree, sizeof(ip_tree_t));
    if (!tree)
        return NULL;

    tree->free = NULL;
    tree->value_delete_func = del_func;

    tree->root = ip_tree_alloc(tree);
    if (!(tree->root))
        return NULL;

    tree->root->right = NULL;
    tree->root->left = NULL;
    tree->root->parent = NULL;
    tree->root->value = NGX_RADIX_NO_VALUE;

    return tree;
}

void
ip_tree_delete(ip_tree_t *tree)
{
    ip_node_delete(tree->root, tree->value_delete_func);

    while (tree->free)
    {
        ip_node_t *free_node = tree->free;
        tree->free = tree->free->right;
        free(free_node);
    }

    free(tree);
}

void
ip_tree_walk(ip_tree_t *tree, walk_function walk_func, void *arg)
{
    ip_tree_walk_helper(tree->root, walk_func, arg);
}

result_t
ip_tree_insert_node(ip_tree_t *tree, uint32_t key, uint32_t mask, void *value)
{
    uint32_t           bit;
    ip_node_t  *node, *next;

    bit = 0x80000000;

    node = tree->root;
    next = tree->root;

    while (mask > 0) {
        if (key & bit) {
            next = node->right;

        } else {
            next = node->left;
        }

        if (next == NULL) {
            break;
        }

        bit >>= 1;
        node = next;
        --mask;
    }

    if (next) {
        if (node->value != NGX_RADIX_NO_VALUE) {
            return FAILED;
        }

        node->value = value;
        return SUCCEED;
    }

    while (mask > 0) {
        next = (ip_node_t *)ip_tree_alloc(tree);
        if (next == NULL) {
            return FAILED;
        }

        next->right = NULL;
        next->left = NULL;
        next->parent = node;
        next->value = NGX_RADIX_NO_VALUE;

        if (key & bit) {
            node->right = next;

        } else {
            node->left = next;
        }

        bit >>= 1;
        node = next;
        --mask;
    }

    node->value = value;

    return SUCCEED;
}

result_t
ip_tree_check_insertable(ip_tree_t *tree, uint32_t key, uint32_t mask)
{
    uint32_t           bit;
    ip_node_t  *node, *next;

    bit = 0x80000000;

    node = tree->root;
    next = tree->root;

    while (mask > 0) {
        if (key & bit) {
            next = node->right;

        } else {
            next = node->left;
        }

        if (next == NULL) {
            break;
        }

        bit >>= 1;
        node = next;
        --mask;
    }

    if (next) {
        if (node->value != NGX_RADIX_NO_VALUE) {
            return FAILED;
        }
    }

    return SUCCEED;
}

result_t
ip_tree_delete_node(ip_tree_t *tree, uint32_t key, uint32_t mask)
{
    uint32_t           bit;
    ip_node_t  *node;

    bit = 0x80000000;
    node = tree->root;

    while (node && mask > 0) {
        if (key & bit) {
            node = node->right;

        } else {
            node = node->left;
        }

        bit >>= 1;
        --mask;
    }

    if (node == NULL) {
        return FAILED;
    }

    if (node->right || node->left) {
        if (node->value != NGX_RADIX_NO_VALUE) {
            if (tree->value_delete_func)
                (tree->value_delete_func)(node->value);
            node->value = NGX_RADIX_NO_VALUE;
            return SUCCEED;
        }

        return FAILED;
    }

    if (node->value != NGX_RADIX_NO_VALUE && tree->value_delete_func)
    {
        (tree->value_delete_func)(node->value);
        node->value = NGX_RADIX_NO_VALUE;
    }

    for ( ;; ) {
        if (node->parent->right == node) {
            node->parent->right = NULL;

        } else {
            node->parent->left = NULL;
        }

        node->right = tree->free;
        tree->free = node;

        node = node->parent;

        if (node->right || node->left) {
            break;
        }

        if (node->value != NGX_RADIX_NO_VALUE) {
            break;
        }

        if (node->parent == NULL) {
            break;
        }
    }

    return SUCCEED;
}

void *
ip_tree_find(ip_tree_t *tree, uint32_t key)
{
    uint32_t           bit;
    void              *value;
    ip_node_t  *node;

    bit = 0x80000000;
    value = NGX_RADIX_NO_VALUE;
    node = tree->root;

    while (node) {
        if (node->value != NGX_RADIX_NO_VALUE) {
            value = node->value;
        }

        if (key & bit) {
            node = node->right;

        } else {
            node = node->left;
        }

        bit >>= 1;
    }

    return value;
}

static void *
ip_tree_alloc(ip_tree_t *tree)
{
    ip_node_t *ptr = NULL;

    if (tree->free)
    {
        ptr = tree->free;
        tree->free = tree->free->right;
        ptr->left = ptr->right = ptr->parent = NULL;
        ptr->value = NGX_RADIX_NO_VALUE;
        return (void *)ptr;
    }

    DIG_MALLOC(ptr, sizeof(ip_node_t));
    return (void *)ptr;
}

static void
ip_node_delete(ip_node_t *node, value_del_function del_func)
{
    if (node)
    {
        if (node->left)
            ip_node_delete(node->left, del_func);

        if (node->right)
            ip_node_delete(node->right, del_func);

        if (!NODE_IS_EMPTY(node) && del_func)
            del_func(node->value);

        free(node);
    }
}

static void
ip_tree_walk_helper(ip_node_t *node, walk_function walk_func, void *arg)
{
    if (node->left)
        ip_tree_walk_helper(node->left, walk_func, arg);

    if (!NODE_IS_EMPTY(node))
        walk_func(node->value, arg);

    if (node->right)
        ip_tree_walk_helper(node->right, walk_func, arg);
}
//static ip_node_t *
//ip_tree_get_leftest_node(ip_tree_t *tree)
//{
//    ip_node_t *node = tree->root;
//
//    while (node->left)
//        node = node->left;
//
//    return node;
//}
//
//static ip_node_t *
//ip_node_next(ip_node_t *node)
//{
//    ip_node_t *next = NULL;
//    if (node->right)
//    {
//        next = node->right;
//        while (next->left)
//            next = next->left;
//
//        return next;
//    }
//
//    ip_node_t *child = node;
//    ip_node_t *father = child->parent;
//    while (father)
//    {
//        if (child == father->left)
//            return father;
//
//        child = father;
//        father = father->parent;
//    }
//
//    return father;
//}
