#ifndef _DIG_UTIL_H_
#define _DIG_UTIL_H_

#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>
#include <stddef.h>
#include <sys/syscall.h>
#include <stdbool.h>
#include <time.h>

#include "dig_error.h"


#define LOG(format, ...)                  \
    fprintf(stderr, " >>  %s [%d] " format "\n",     \
            __FUNCTION__, __LINE__, ##__VA_ARGS__)


//#define PROFILE_ENABLE

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))

#define TRACE(mod, name, stat) \
        printf("%s in (%s)(%d)(%s) failed(%s)\n", \
        #name, __FILE__, __LINE__, __FUNCTION__, result_to_str(stat)); 

#define CHECK(func) \
do {\
    ret = func; \
    if (SUCCEED != ret) \
    {\
        TRACE(DIG_ERROR, #func, ret); \
        return ret;\
    } \
}while (0);
 

#define DIG_MALLOC(p,size) do {\
    (p) = malloc((size));\
}while(0)

#define DIG_REALLOC(p, new_size) do{\
    (p) = realloc((p), new_size);\
}while(0)

#define DIG_CALLOC(p, count, size) do {\
    (p) = calloc((count), (size));\
}while(0)

#define DIG_FREE(p) do {\
    if (NULL != (p)) {free(p); (p) = NULL; }\
}while(0)


/**
 * added by db: 
 *      in domain_table_t and releate struct may be
 *      use mmap, while after deserialize from binary zone file.
 *      so, those memory cant be free with free()....
 */ 
#define ALIGN32(a) (((a) + 3) >> 2 << 2)
#define ALIGN64(a) (((a) + 7) >> 3 << 3)
#define ALIGN_BYTES(a) ALIGN64(a) 

#define DIG_MEM_ENABLE_MMAP 1
#ifdef DIG_MEM_ENABLE_MMAP
// this struct MUST be 8-bytes align ...
typedef struct __dig_mem_type_t__
{
#define DIG_MEM_MAGIC 0x9DEF6BA5
    unsigned int __magic;
#define DIG_MEM_TYPE_STACK (0x01)
#define DIG_MEM_TYPE_HEAP (0x02)
#define DIG_MEM_TYPE_MMAP (0x04)
    unsigned char __type;

    unsigned char __pad0[3];
}dig_mem_type_t;

#define DIG_MEM_TYPE_LEN (sizeof(dig_mem_type_t))

#define DIG_MEM_CHECK_IS_IN_HEAP(p)  \
    ( ((p)->__magic == DIG_MEM_MAGIC) && ((p)->__type == DIG_MEM_TYPE_HEAP ))
    
#define DIG_MEM_CHECK_IS_IN_MMAP(p)  \
    ( ((p)->__magic == DIG_MEM_MAGIC) && ((p)->__type == DIG_MEM_TYPE_MMAP ))

#define ___FILL_PAD3__(p) do { \
    (p)->__pad0[0] = (p)->__pad0[1] = (p)->__pad0[2] = 0; \
}while(0)
#define DIG_MEM_IN_MMAP(p) do { \
    (p)->__magic = DIG_MEM_MAGIC; \
    (p)->__type = DIG_MEM_TYPE_MMAP; \
    ___FILL_PAD3__(p); \
}while(0)

#define DIG_MEM_IN_HEAP(p) do { \
    (p)->__magic = DIG_MEM_MAGIC; \
    (p)->__type = DIG_MEM_TYPE_HEAP; \
    ___FILL_PAD3__(p); \
}while(0)

// define UTIL for user data struct
#define DIG_MEM_STRUCT_SIZEOF(type) (sizeof(type) + sizeof(dig_mem_type_t))
#define __MAKE_STRUCT_NAME1__(x, y, z) __ ## x ## _ ## y ## _ ## z ## _t__
#define __MAKE_STRUCT_NAME2__(x, y, z) __MAKE_STRUCT_NAME1__(x , y, z) 
#define __MAKE_STRUCT_NAME__(x, y) __MAKE_STRUCT_NAME2__(x , y, __LINE__) 

#define DIG_MEM_STRUCT_DEFINE(type, name) \
struct __MAKE_STRUCT_NAME__(type, name) { \
    dig_mem_type_t ___mem_type; \
    type __ ## name; \
}name; \
memset(&name, 0x0, sizeof(name)); \
DIG_MEM_IN_MMAP(&(name.___mem_type));

#define DIG_MEM_DUMP_TYPE(address) do{ \
    dig_mem_type_t __tmp__; \
    DIG_MEM_IN_MMAP(&__tmp__); \
    memcpy((address), &__tmp__, sizeof(__tmp__)); \
}while(0)

#define DIG_MEM_DUMP_TYPE2(offset, file) do{ \
    dig_mem_type_t __tmp__; \
    DIG_MEM_IN_MMAP(&__tmp__); \
    fseek(file, offset, SEEK_SET); \
    fwrite(&__tmp__, sizeof(__tmp__), 1, file); \
}while(0)

//sauteed.
#define DIG_MEM_TYPE_FILL_IN(base, offset) do {\
    DIG_MEM_IN_MMAP((dig_mem_type_t*)(base)); \
    offset += DIG_MEM_TYPE_LEN; \
} while(0)

#define DIG_MEM_RDATA_FILL_IN(base, data, size, offset) do {\
    memcpy(base, data, size); \
    offset += size; \
} while(0)

#define DIG_MEM_STRUCT_DATA(name) (name.__ ## name)
#define DIG_MEM_STRUCT_FIELD(name, field) (name.__ ## name.field)

// define memory malloc/free wrapper
#define DIG_MEM_MALLOC(p,size) do {\
    char *___tmp___ = malloc((size) + sizeof(dig_mem_type_t));\
    if (NULL != (___tmp___)) { \
        *((char **)(&(p))) = (char *)(___tmp___ + sizeof(dig_mem_type_t)); \
        DIG_MEM_IN_HEAP((dig_mem_type_t*)___tmp___); \
    } \
}while(0)

#define DIG_MEM_REALLOC(p, new_size) do{\
    char *___tmp___ = realloc((size) + sizeof(dig_mem_type_t));\
    if (NULL != (___tmp___)) { \
        *(char **)(&(p)) = ___tmp___ + sizeof(dig_mem_type_t); \
        DIG_MEM_IN_HEAP((dig_mem_type_t*)___tmp___); \
    } \
}while(0)

#define DIG_MEM_CALLOC(p, count, size) do {\
    char *___tmp___ = calloc((count), (size) + sizeof(dig_mem_type_t));\
    if (NULL != ___tmp___) { \
        *(char **)(&(p)) = ___tmp___ + sizeof(dig_mem_type_t); \
        DIG_MEM_IN_HEAP((dig_mem_type_t*)___tmp___); \
    } \
}while(0)

#define DIG_MEM_FREE(p) do{ \
    if (NULL != (p) &&  (void*)(p) > (void*)sizeof(dig_mem_type_t)) { \
        dig_mem_type_t *___tmp___ = ((dig_mem_type_t*)(p)) - 1; \
        if (DIG_MEM_CHECK_IS_IN_HEAP(___tmp___)) free(___tmp___); \
    } \
    (p) = NULL; \
}while(0)
#else // UNDEFINE DIG_MEM_ENABLE_MMAP

#define DIG_MEM_TYPE_LEN (0) 
#define DIG_MEM_STRUCT_SIZEOF(type) (sizeof(type))

#define DIG_MEM_STRUCT_DEFINE(type, name) type name 
#define DIG_MEM_STRUCT_FIELD(name, field) name.field 
#define DIG_MEM_STRUCT_DATA(name) (name)

#define DIG_MEM_DUMP_TYPE(address) do{ (void)address; }while(0)
#define DIG_MEM_DUMP_TYPE2(offset, file) do{ (void)offset; (void)file; }while(0) 

#define DIG_MEM_MALLOC(p,size) do {\
    (p) = malloc((size));\
}while(0)

#define DIG_MEM_REALLOC(p, new_size) do{\
    (p) = realloc((p), new_size);\
}while(0)

#define DIG_MEM_CALLOC(p, count, size) do {\
    (p) = calloc((count), (size));\
}while(0)

#define DIG_MEM_FREE(p) do{ \
    if (NULL != (p)) { \
        free(p); \
        (p) = NULL; \
    } \
}while(0)
#endif
//////////////////////////////////////////////////////////////////////


#define ASSERT(cond,...)    do{ \
    if (!(cond))  { \
        char str[200]; \
        sprintf(str, __VA_ARGS__); \
        int length = strlen(str); \
        if (str[length - 1] == '\n') \
        {\
            str[length - 1] = 0;\
        }\
        printf("%s in file %s at line %d.\n", str, __FILE__, __LINE__);\
        exit(1);    \
    }\
}while(0)

typedef struct timeval timeval_t;
#ifdef PROFILE_ENABLE
    #define PROFILE_START(start) gettimeofday(&(start), NULL)
    #define PROFILE_END(start, info) do{\
        struct timeval _end, _diff;\
        gettimeofday(&_end, NULL);\
        timersub(&_end, &start, &_diff);\
        printf("%s elapsed %f s\n", (info), (_diff.tv_sec + _diff.tv_usec)/ 1000000.0);\
    }while(0)
#else
    #define PROFILE_START(start) (start = start)
    #define PROFILE_END(start, info) 
#endif
/*
 * Return -1, 0, 1 when t1 respectively less than, equal to or
 * more than t2.
 */
static inline int
time_compare(struct timeval *t1, struct timeval *t2)
{
    if (t1->tv_sec > t2->tv_sec)
        return 1;
    else if (t1->tv_sec < t2->tv_sec)
        return -1;
    else if (t1->tv_usec > t2->tv_usec)
        return 1;
    else if (t1->tv_usec < t2->tv_usec)
        return -1;
    else
        return 0;
}



/*
 * return 1 if s1 is the latest one, else 0.
 */
static inline int
serial_valid(uint32_t s1, uint32_t s2)
{
    uint32_t mod = 1;
    mod = mod<<31;
    if( ((s1 < s2)&&(s2 - s1 > mod)) \
            || ((s1 > s2)&&(s1 - s2 < mod)))
        return 1;
    return 0;
}

/* Add some seconds to origin t1(type is struct timeval)  */
#define TIME_ADD(t1, seconds, t2) \
do	\
{	\
	(t2)->tv_sec = (t1)->tv_sec + seconds;	\
	(t2)->tv_usec = (t1)->tv_usec;	\
}while(0)


static inline unsigned long threadid(void)
{
    return syscall(SYS_gettid)-getpid();
}

/*
 * return the absolute path base on one known absolute path
 * path_may_be_relative is one path maybe relative,
 * if path_may_be_relative is absolute path, the return value will be equal to it
 * otherwise return base_absolute_path + path_may_be_relative
 * */
char *get_absolut_path_base_on_path(const char *path_may_be_relative, const char *base_absolute_path);

bool
get_absolut_path(const char *work_path, const char *file_path, char *absolut_path);

void 
print_tool_version(const char *tool_name);

char *
trim(char **src);

int
chrcnt(const char *string,int letter);

result_t
get_token(char *text, char **section);

long long
tokenToNum(char *token, int bitsize);

void
strtrim(char *str);

time_t
time_from_utc(const struct tm *tm);

char *
strcopy(const char *str);

void print_stack(int line, char *filename, char *str);

result_t
split(const char *src_str, int src_len, const char *delim, 
        char **split_array, int split_array_len, int *elem_cnt);

#endif
