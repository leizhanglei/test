#include <sys/types.h>
#include <dirent.h>
#include <ctype.h>
#include <execinfo.h>
#include <jemalloc/jemalloc.h>

#include "dig_utils.h"
#include "dig_buffer.h"
#include "dig_error.h"
#include "config.h"

void
print_stack(int line, char *filename, char *str)
{
    printf("assert failed at line %d of file %s :\n%s\n", line, filename, str);

    void * array[25];
    int nsize = backtrace(array, 25);
    char ** symbols = backtrace_symbols(array, nsize);
    printf( "----------ASSERT call stack ----------\n");

    int i = 0;
    for (; i < nsize; i++)
         printf( "%s\n",symbols[i]);

    printf( "--------------------------------------\n");

    free(symbols);
}

bool
path_is_absolut(const char *file_path)
{
    if (file_path[0] == '/')
        return true;
    else
        return false;
}

void
filepath2path(char *file_path)
{
    int i;

    for (i = strlen(file_path); i >= 0; i--)
    {
        if (file_path[i] == '/')
        {
            file_path[i+1] = '\0';
            return;
        }
    }
}

static bool
check_path_has_slash(const char *path)
{
    int i = strlen(path);
    for (; i >= 0; i--)
        if ('/' == path[i])
            return true;

    return false;
}

bool
get_absolut_path(const char *work_path, const char *file_path, char *absolut_path)
{
    char full_path[PATH_MAX];
    FILE *fp = NULL;
    char path[PATH_MAX];

    if (path_is_absolut(file_path))
    {
        strcpy(absolut_path, file_path);
        return true;
    }

    if (check_path_has_slash(work_path))
    {
        strcpy(path, work_path);
        filepath2path(path);

        strcpy(full_path, path);
        strcat(full_path, "/");
        strcat(full_path, file_path);
    }
    else
        strcpy(full_path, file_path);

    fp = fopen(full_path, "r");
    if (!fp)
    {
        strcpy(absolut_path, full_path);
        return false;
    }

    fclose(fp);
    strcpy(absolut_path, full_path);

    return true;
}

char*
trim(char **src)
{
    if (NULL == src || NULL == *src)
        return NULL;
    char *head = *src;
    char *end = *src + strlen(*src);
    while (head && *head && isspace(*head))
        ++head;
    while ((end>head) && end && *end && isspace(*end))
        --end;

    char *ptr = NULL;
    if (head > end)
    {
        ptr = malloc(1);
        ptr[0] = '\0';
    }
    else
    {
        int len = end - head + 1;
        ptr = malloc(len+1);
        strncpy(ptr, head, len);
        ptr[len] = '\0';
    }

    free(*src);
    *src = ptr;
    return ptr;
}

/**
 * Get the appearance count of one char in a string.
 */
int
chrcnt(const char *string,int letter)
{
    int count = 0;
    while(*string)
        if(*(string++) == letter) count++;
    return count;
}

/**
 * Trim head and tail spaces
 */
void
strtrim(char *str)
{
    if (str == NULL )
        return;

    // trim left and right space
    char *head = str;
    char *tail = str + strlen(str) - 1;
    for(; isspace(*head); head++ );
    for(; isspace(*tail) && (tail >= head); tail--);
    while(head <= tail)
        *str++ = *head++;

    *str = '\0';
}

char *
strcopy(const char *str)
{
    char *text = NULL;
    DIG_MALLOC(text, strlen(str) + 1);
    if (text == NULL) {
        printf( "Alloc memory failed: no enough memory.\n");
        return NULL;
    }
    strcpy(text, str);

    return text;
}

result_t
get_token(char *text, char **section)
{
    char seps[] = " \f\t\v";
    strtrim(text);
    int left_len = strlen(text);
    *section = strtok(text, seps);

    // This shouldn't be the last section of RR
    if (left_len == strlen(*section))
        return FAILED;

    return SUCCEED;
}

long long
tokenToNum(char *token, int bitsize)
{
    long long num = strtoll(token, NULL, 10);
    // out of range
    if ((num < 0) || (num >= ((long long)(1) << bitsize)))
    {
        printf( "section %s out of range.\n", token);
        return -1;
    }

    return num;
}

static const int mdays[] = {
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

static int
leap_days(int y1, int y2)
{
    --y1;
    --y2;
    return (y2/4 - y1/4) - (y2/100 - y1/100) + (y2/400 - y1/400);
}

static int
is_leap_year(int year)
{
    return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
}

time_t
time_from_utc(const struct tm *tm)
{       
    int year = 1900 + tm->tm_year;
    time_t days = 365 * (year - 1970) + leap_days(1970, year);
    time_t hours;
    time_t minutes;
    time_t seconds;
    int i;

    for (i = 0; i < tm->tm_mon; ++i) {
        days += mdays[i];
    }
    if (tm->tm_mon > 1 && is_leap_year(year)) {
        ++days;
    }
    days += tm->tm_mday - 1;

    hours = days * 24 + tm->tm_hour;
    minutes = hours * 60 + tm->tm_min;
    seconds = minutes * 60 + tm->tm_sec;

    return seconds;
}   

void
print_tool_version(const char *tool_name)
{
    fprintf(stderr, "%s version %s\n", tool_name, PACKAGE_VERSION);
    fprintf(stderr, "Written by CNNIC Labs.\n");
    fprintf(stderr,
            "Copyright (C) 2008-2009 CNNIC Labs.\n");
}

result_t
split(const char *src_str, int src_len, const char *delim, 
        char **split_array, int split_array_len, int *elem_cnt)
{
    if (!src_str || !delim || !split_array || !elem_cnt)
        return FAILED;

    if (strlen(src_str) < src_len)
        return FAILED;

    *elem_cnt = 0;

    char *begin = (char *)src_str;
    char *end = (char *)(src_str + src_len);
    char *delim_pos = NULL;
    int len = 0;
    int i = 0;
    while (begin < end)
    {
        delim_pos = strstr(begin, delim);
        if (delim_pos)
            len = delim_pos - begin;
        else
            len = end - begin;

        if (len > 0)
        {
            if ((*elem_cnt + 1) > split_array_len)
                goto SPLIT_FAILED;

            split_array[*elem_cnt] = malloc(len + 1);
            if (NULL == split_array[*elem_cnt])
                goto SPLIT_FAILED;

            strncpy(split_array[*elem_cnt], begin, len);
            (split_array[*elem_cnt])[len] = '\0';
            *elem_cnt = *elem_cnt + 1;
        }

        if (delim_pos)
            begin = delim_pos + strlen(delim);
        else
            begin = end;
    }

    return SUCCEED;

SPLIT_FAILED :
    for (i = 0; i < *elem_cnt; ++i)
    {
        free(split_array[i]);
        split_array[i] = NULL;
    }

    *elem_cnt = 0;
    return FAILED;
}
