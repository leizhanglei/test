#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Automated.h>
#include <CUnit/Console.h>

#include "config.h"
#include "dig_conf_mgr.h"
#include "dig_intelligent_resolver_mgr.h"

static void test_init_ir_mgr_from_conf()
{
	conf_mgr_t* conf_mgr = conf_mgr_create();
	CU_ASSERT(conf_mgr != NULL);

	result_t ret = init_conf_mgr(conf_mgr, MAPLE_TOP_DIR "/tests/db/acl.conf");
	CU_ASSERT(ret == SUCCEED)

	ret = ir_mgr_create();
	CU_ASSERT(ret == SUCCEED)

	ret = init_ir_mgr_from_conf(conf_mgr);
	CU_ASSERT(ret == SUCCEED)
}

static void test_get_viewid_by_addr()
{
	//const char* view;
	char* rela_name = "system";
	char* ip1 = "192.168.2.1";
	struct sockaddr_in addr1;
	addr1.sin_addr.s_addr = inet_network(ip1);
	addr1.sin_addr.s_addr = htonl(*(uint32_t*)(&addr1.sin_addr.s_addr));

	rela_iptrees_t* iptrees = get_iptrees_by_rela_name(rela_name);
	uint32_t view_id = get_viewid_by_addr(iptrees, (struct sockaddr*)(&addr1));
	CU_ASSERT(view_id == 0x0);

	rela_name = "relation2";
	ip1 = "192.168.210.128";
	addr1.sin_addr.s_addr = inet_network(ip1);
	addr1.sin_addr.s_addr = htonl(*(uint32_t*)(&addr1.sin_addr.s_addr));

	iptrees = get_iptrees_by_rela_name(rela_name);
	view_id = get_viewid_by_addr(iptrees,(struct sockaddr*)(&addr1));
	printf("ip : %d\n", view_id);
	CU_ASSERT(view_id == 0x5);

}

static void test_get_viewid_by_viewname()
{
	char* view = "view1";
	uint16_t view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x1);

	view = "view2";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x2);
	
	view = "view3";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x3);

	view = "view4";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x4);

	view = "view5";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x5);

	view = "view6";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x6);

	view = "default";
	view_id = get_viewid_by_viewname(view);
	CU_ASSERT(view_id == 0x0);
}

static void test_get_viewname_by_viewid()
{
	uint16_t view_id = 1;
	char* view_name = get_viewname_by_viewid(view_id);
	int ret = strcmp(view_name, "view1");
	CU_ASSERT(ret == 0);

	view_id = 2;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "view2");
	CU_ASSERT(ret == 0);

	view_id = 3;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "view3");
	CU_ASSERT(ret == 0);

	view_id = 4;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "view4");
	CU_ASSERT(ret == 0);

	view_id = 5;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "view5");
	CU_ASSERT(ret == 0);

	view_id = 6;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "view6");
	CU_ASSERT(ret == 0);

	view_id = 0;
	view_name = get_viewname_by_viewid(view_id);
	ret = strcmp(view_name, "default");
	CU_ASSERT(ret == 0);
}

static void test_ir_mgr_destroy()
{
	ir_mgr_destroy();
}

static CU_TestInfo rr_ir_mgr_test[] = {
	{"test_init_ir_mgr_from_conf", test_init_ir_mgr_from_conf},
	{"test_get_viewid_by_addr", test_get_viewid_by_addr},
	{"test_get_viewid_by_viewname", test_get_viewid_by_viewname},
	{"test_get_viewname_by_viewid", test_get_viewname_by_viewid},
	{"test_ir_mgr_destroy", test_ir_mgr_destroy},
    CU_TEST_INFO_NULL,
};



static CU_SuiteInfo  first_suit[] = {
    {"rr_ir_mgr_test", NULL, NULL, rr_ir_mgr_test},
    CU_SUITE_INFO_NULL,
};

<%= main_entry%>
