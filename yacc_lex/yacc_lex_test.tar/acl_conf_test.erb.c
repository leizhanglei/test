#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <CUnit/Automated.h>
#include <CUnit/Console.h>

#include "config.h"
#include "dig_acl_conf.h"

static void acl_conf_test()
{
	//add acl1
	acl_conf_t* acl_conf1 = acl_conf_create("acl1");
	CU_ASSERT(acl_conf1 != NULL);

	result_t ret = acl_conf_insert_acl(acl_conf1, "192.168.1.10");
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_insert_acl(acl_conf1, "192.168.1.11/24");
	CU_ASSERT(ret == SUCCEED);
	
	//add acl2
	acl_conf_t* acl_conf2 = acl_conf_create("acl2");
	CU_ASSERT(acl_conf2 != NULL);

	ret = acl_conf_insert_acl(acl_conf2, "192.168.2.10");
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_insert_acl(acl_conf2, "192.168.2.11/24");
	CU_ASSERT(ret == SUCCEED);

	//add acl3
	acl_conf_t* acl_conf3 = acl_conf_create("acl3");
	CU_ASSERT(acl_conf3 != NULL);

	ret = acl_conf_insert_acl(acl_conf3, "192.168.3.10");
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_insert_acl(acl_conf3, "192.168.3.11/24");
	CU_ASSERT(ret == SUCCEED);

	//add acl4
	acl_conf_t* acl_conf4 = acl_conf_create("acl4");
	CU_ASSERT(acl_conf4 != NULL);

	ret = acl_conf_insert_acl(acl_conf4, "192.168.4.10");
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_insert_acl(acl_conf4, "192.168.4.11/24");
	CU_ASSERT(ret == SUCCEED);

	//acl conf mgr add acl conf
	acl_conf_mgr_t* acl_conf_mgr = acl_conf_mgr_create();
	CU_ASSERT(acl_conf_mgr != NULL);

	ret = acl_conf_mgr_insert_acl_conf(acl_conf_mgr, acl_conf1);
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_mgr_insert_acl_conf(acl_conf_mgr, acl_conf2);
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_mgr_insert_acl_conf(acl_conf_mgr, acl_conf3);
	CU_ASSERT(ret == SUCCEED);

	ret = acl_conf_mgr_insert_acl_conf(acl_conf_mgr, acl_conf4);
	CU_ASSERT(ret == SUCCEED);

	//add view1
	view_conf_t *view1 = view_conf_create("view1");
	CU_ASSERT(view1 != NULL);

	ret = view_conf_insert_acl(view1, "acl1");
	CU_ASSERT(ret == SUCCEED);

	ret = view_conf_insert_acl(view1, "acl2");
	CU_ASSERT(ret == SUCCEED);

	//add view2
	view_conf_t *view2 = view_conf_create("view2");
	CU_ASSERT(view2 != NULL);

	ret = view_conf_insert_acl(view2, "acl3");
	CU_ASSERT(ret == SUCCEED);

	ret = view_conf_insert_acl(view2, "acl4");
	CU_ASSERT(ret == SUCCEED);
	
	//view conf mgr add view conf
	view_conf_mgr_t *view_conf_mgr = view_conf_mgr_create();
	CU_ASSERT(view_conf_mgr != NULL);

	ret = view_conf_mgr_insert_view(view_conf_mgr, view1);
	CU_ASSERT(ret == SUCCEED);

	ret = view_conf_mgr_insert_view(view_conf_mgr, view2);
	CU_ASSERT(ret == SUCCEED);
	
	//mgr
	smartdns_conf_mgr_t* smart_conf_mgr = smartdns_conf_mgr_create();
	CU_ASSERT(smart_conf_mgr != NULL);

	smartdns_conf_t* smart_conf = smartdns_conf_create("user1");
	CU_ASSERT(smart_conf != NULL);

	ret = smartdns_conf_set_acls(smart_conf, acl_conf_mgr);
	CU_ASSERT(ret == SUCCEED);

	ret = smartdns_conf_set_views(smart_conf, view_conf_mgr);
	CU_ASSERT(ret == SUCCEED);

	ret = smartdns_conf_mgr_insert_smartdns_conf(smart_conf_mgr, smart_conf);
	CU_ASSERT(ret == SUCCEED);

	ret = smartdns_conf_mgr_iter_begin(smart_conf_mgr);
	CU_ASSERT(ret == SUCCEED);

	smartdns_conf_t* smart_conf_tmp = smartdns_conf_mgr_iter_next(smart_conf_mgr);	
	while(smart_conf_tmp) {
		view_conf_mgr_t* view_conf_mgr_tmp = smartdns_conf_get_views(smart_conf_tmp);
		CU_ASSERT(view_conf_mgr_tmp != NULL);

		acl_conf_mgr_t* acl_conf_mgr_tmp = smartdns_conf_get_acls(smart_conf_tmp);
		CU_ASSERT(acl_conf_mgr_tmp != NULL);

		ret = view_conf_mgr_iter_begin(view_conf_mgr_tmp);
		CU_ASSERT(ret == SUCCEED);

		view_conf_t* view_conf_tmp = view_conf_mgr_iter_next(view_conf_mgr_tmp);	
		while(view_conf_tmp) {
			CU_ASSERT(view_conf_tmp != NULL);

			ret = view_conf_iter_begin(view_conf_tmp);
			CU_ASSERT(ret == SUCCEED);

			const char* view_acl_name = NULL;
			while( (view_acl_name = view_conf_iter_next(view_conf_tmp)) ) {
				acl_conf_t* acl_conf_tmp = (acl_conf_t*)acl_conf_mgr_find_acl_by_name(acl_conf_mgr_tmp, view_acl_name);
				CU_ASSERT(acl_conf_tmp != NULL);

				ret = acl_conf_iter_begin(acl_conf_tmp);
				if (ret != SUCCEED) exit(1);
				CU_ASSERT(ret == SUCCEED);

				while(1) {
					const char* ip = NULL;
					uint32_t mask = 0;
					ip = acl_conf_iter_next(acl_conf_tmp, &mask);

					if (!ip) break;

					printf("%s : %d\n", ip, mask);

					CU_ASSERT(ret == SUCCEED);
				}

			}
			
			view_conf_tmp = view_conf_mgr_iter_next(view_conf_mgr_tmp);	
		}

		smart_conf_tmp = smartdns_conf_mgr_iter_next(smart_conf_mgr);	
	}
	
	smartdns_conf_mgr_destroy(smart_conf_mgr);
}


static CU_TestInfo acl_conf_tests[] = {
	{"acl_conf_test", acl_conf_test},
    CU_TEST_INFO_NULL,
};



static CU_SuiteInfo  first_suit[] = {
    {"acl_conf_tests", NULL, NULL, acl_conf_tests},
    CU_SUITE_INFO_NULL,
};

<%= main_entry%>
