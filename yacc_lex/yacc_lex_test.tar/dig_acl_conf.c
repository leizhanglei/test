#include "dig_acl_conf.h"

acl_conf_t *
acl_conf_create(const char *name)
{
	acl_conf_t* ac = NULL;
	DIG_MALLOC(ac, sizeof(acl_conf_t));
	if (!ac) return NULL;

	memset(ac, 0x00, sizeof(acl_conf_t));
	strcpy(ac->name, name);
	return ac;
}

static uint32_t
calculate_mask(const char* str_ip, uint32_t* mask_pos)
{
	if (str_ip == NULL)
		return 0;

	char* pos = strchr(str_ip, '/');
	if (pos == NULL)
		return 32;

	char* str_mask = pos + 1;
	if (str_mask == NULL || strlen(str_mask) < 0)
		return -1;

	//pos[0] = '\0';
	*mask_pos = (uint32_t)pos - (uint32_t)str_ip;
	return atoi(str_mask);
}

result_t
acl_conf_insert_acl(acl_conf_t *acls, const char *str)
{
	if (!acls || !str) return FAILED;

	acl_conf_elem_t* ace = NULL;
	DIG_MALLOC(ace, sizeof(acl_conf_elem_t));
	if (!ace) return FAILED;

	memset(ace, 0x00, sizeof(acl_conf_elem_t));

	uint32_t mask_pos = strlen(str);
	ace->mask = calculate_mask(str, &mask_pos);
	memcpy(ace->ip, str, mask_pos);

	if(!acls->acls && !acls->iter_ptr) {
		acls->acls = acls->iter_ptr = ace;
		return SUCCEED;
	}

	acl_conf_elem_t* tmp = acls->acls;
	while(tmp) {
		if (!tmp->next) {
			tmp->next = ace;
			break;
		}

		tmp = tmp->next;
	}

	return SUCCEED;
}

result_t 
acl_conf_iter_begin(acl_conf_t *acls)
{
	if (!acls) return FAILED;
	
	acls->iter_ptr = acls->acls;
	return SUCCEED;
}

const char *
acl_conf_iter_next(acl_conf_t *acls, uint32_t *mask)
{
	if (!acls) return NULL;
	if (!acls->iter_ptr) return NULL;

	acl_conf_elem_t* tmp = acls->iter_ptr;
	if (acls->iter_ptr->next) acls->iter_ptr = acls->iter_ptr->next;
	else acls->iter_ptr = NULL;

	*mask = tmp->mask;
	return tmp->ip;
}

acl_conf_mgr_t *
acl_conf_mgr_create()
{
	acl_conf_mgr_t* acm = NULL;
	DIG_MALLOC(acm, sizeof(acl_conf_mgr_t));
	
	if(!acm) return NULL;

	memset(acm, 0x00, sizeof(acl_conf_mgr_t));

	return acm;
}

const acl_conf_t *
acl_conf_mgr_find_acl_by_name(acl_conf_mgr_t *mgr, const char *acl_name)
{
	if (!mgr || !acl_name) return NULL;
	acl_conf_mgr_iter_begin(mgr);

	acl_conf_t *tmp = acl_conf_mgr_iter_next(mgr); 
	while (tmp) {
		if (strcmp(tmp->name, acl_name) == 0)
			return tmp;

		tmp = acl_conf_mgr_iter_next(mgr); 
	}
	
	return NULL;
}

result_t
acl_conf_mgr_insert_acl_conf(acl_conf_mgr_t *mgr, acl_conf_t *conf)
{
	if (!mgr || !conf) return FAILED;

	if (!mgr->list && !mgr->iter_ptr) {
		mgr->list = mgr->iter_ptr = conf;
		return SUCCEED;
	}

	acl_conf_t* tmp = mgr->list;
	while(tmp) {
		if (!tmp->next) {
			tmp->next = conf;
			break;
		}

		tmp = tmp->next;
	}

	return SUCCEED;	
}

result_t 
acl_conf_mgr_iter_begin(acl_conf_mgr_t *mgr)
{
	if (!mgr) return FAILED;

	mgr->iter_ptr = mgr->list;
}

acl_conf_t *
acl_conf_mgr_iter_next(acl_conf_mgr_t *mgr)
{
	if (!mgr) return NULL;

	acl_conf_t* tmp = mgr->iter_ptr;
	if (mgr->iter_ptr->next) mgr->iter_ptr = mgr->iter_ptr->next;
	else mgr->iter_ptr = NULL;

	return tmp;
}

view_acl_t *
view_acl_create(const char* acl_name)
{
	view_acl_t* va = NULL;
	DIG_MALLOC(va, sizeof(view_acl_t));	
	if (!va) return NULL;

	memset(va, 0x00, sizeof(view_acl_t));
	strcpy(va->acl_name, acl_name);
	return va;
}

view_conf_t *
view_conf_create(const char* view_name)
{
	view_conf_t* vc = NULL;
	DIG_MALLOC(vc, sizeof(view_conf_t));	
	if (!vc) return NULL;

	memset(vc, 0x00, sizeof(view_conf_t));
	strcpy(vc->view_name, view_name);
	return vc;
}

result_t
view_conf_set_view_id(view_conf_t* conf, uint32_t view_id)
{
	if (!conf) return FAILED;
	
	conf->view_id = view_id;
}

result_t
view_conf_insert_acl(view_conf_t *conf, const char *acl_name)
{
	if (!conf || !acl_name) return FAILED;

	view_acl_t* va = view_acl_create(acl_name);
	if (!va) return FAILED;

	if (!conf->acls && !conf->iter_ptr) {
		conf->acls = conf->iter_ptr = va;
		return SUCCEED;
	}

	view_acl_t* tmp = conf->acls;
	while(tmp) {
		if (!tmp->next) {
			tmp->next = va;	
			break;
		}
		
		tmp = tmp->next;
	}

	return SUCCEED;
}

result_t
view_conf_iter_begin(view_conf_t *conf)
{
	if (!conf) return FAILED;

	conf->iter_ptr = conf->acls;		
	return SUCCEED;
}

const char *
view_conf_iter_next(view_conf_t *conf)
{
	if (!conf) return NULL;

	view_acl_t* tmp = conf->iter_ptr;
	if (!tmp) return NULL;

	if (conf->iter_ptr->next) conf->iter_ptr = conf->iter_ptr->next;
	else conf->iter_ptr = NULL;

	return tmp->acl_name;
}

view_conf_mgr_t *
view_conf_mgr_create()
{
	view_conf_mgr_t* vcm = NULL;
	DIG_MALLOC(vcm, sizeof(view_conf_mgr_t));
	if (!vcm) return NULL;

	memset(vcm, 0x00, sizeof(view_conf_mgr_t));
	return vcm;
}

result_t 
view_conf_mgr_insert_view(view_conf_mgr_t *mgr, view_conf_t *view)
{
	if (!mgr || !view) return FAILED;

	if (!mgr->views && !mgr->iter_ptr) {
		mgr->views = mgr->iter_ptr = view;
		return SUCCEED;
	}

	view_conf_t *tmp = mgr->views;
	while(tmp) {
		if (!tmp->next)	{
			tmp->next = view;
			break;
		}

		tmp = tmp->next;
	}

	return SUCCEED;
}

result_t
view_conf_mgr_iter_begin(view_conf_mgr_t *mgr)
{
	if (!mgr) return FAILED;
	
	mgr->iter_ptr = mgr->views;
	return SUCCEED;
}

view_conf_t *
view_conf_mgr_iter_next(view_conf_mgr_t *mgr)
{
	if (!mgr) return NULL;

	view_conf_t* tmp = mgr->iter_ptr;
	if (!tmp) return NULL;

	if (mgr->iter_ptr->next) mgr->iter_ptr = mgr->iter_ptr->next;
	else mgr->iter_ptr = NULL;

	return tmp;
	
}

smartdns_conf_t *
smartdns_conf_create(const char *name)
{
	if (!name) return NULL;

	smartdns_conf_t *sc = NULL;
	DIG_MALLOC(sc, sizeof(smartdns_conf_t));
	if (!sc) return NULL;

	memset(sc, 0x00, sizeof(smartdns_conf_t));
	strcpy(sc->name, name);
	return sc;
}

result_t 
smartdns_conf_set_acls(smartdns_conf_t *conf, acl_conf_mgr_t *acls)
{
	if (!conf || !acls) return FAILED;

	conf->acls = acls;

	return SUCCEED;
}

acl_conf_mgr_t *
smartdns_conf_get_acls(smartdns_conf_t *conf)
{
	if (!conf) return NULL;

	return conf->acls;
}

result_t
smartdns_conf_set_views(smartdns_conf_t *conf, view_conf_mgr_t *views)
{
	if (!conf || !views) return FAILED;

	conf->views = views;
	
	return SUCCEED;
}

view_conf_mgr_t *
smartdns_conf_get_views(smartdns_conf_t *conf)
{
	if (!conf) return NULL;

	return conf->views;
}

smartdns_conf_mgr_t *
smartdns_conf_mgr_create()
{
	smartdns_conf_mgr_t *scm = NULL;
	DIG_MALLOC(scm, sizeof(smartdns_conf_mgr_t));
	if (!scm) return NULL;

	memset(scm, 0x00, sizeof(smartdns_conf_mgr_t));
	return scm;
}

result_t
smartdns_conf_mgr_insert_smartdns_conf(smartdns_conf_mgr_t *mgr, smartdns_conf_t *conf)
{
	if (!mgr || !conf) return FAILED;

	if (!mgr->confs && !mgr->iter_ptr) {
		mgr->confs = mgr->iter_ptr = conf;
		return SUCCEED;
	}

	smartdns_conf_t* tmp = mgr->confs;
	while(tmp) {
		if (!tmp->next) {
			tmp->next = conf;
			break;
		}
		
		tmp = tmp->next;
	}

	return SUCCEED;
}

result_t
smartdns_conf_mgr_iter_begin(smartdns_conf_mgr_t *mgr)
{
	if (!mgr) return FAILED;
	
	mgr->iter_ptr = mgr->confs;
	return SUCCEED;
}

smartdns_conf_t *
smartdns_conf_mgr_iter_next(smartdns_conf_mgr_t *mgr)
{
	if (!mgr) return NULL;

	smartdns_conf_t* tmp = mgr->iter_ptr;
	if (!tmp) return NULL;

	if (mgr->iter_ptr->next) mgr->iter_ptr = mgr->iter_ptr->next;
	else mgr->iter_ptr = NULL;

	return tmp;
	
}

void
acl_conf_destroy(acl_conf_t* conf)
{
	if (!conf) return;

	acl_conf_iter_begin(conf);	
	while (conf->iter_ptr) {
		acl_conf_elem_t* ace = conf->iter_ptr;
		conf->iter_ptr = conf->iter_ptr->next;

		DIG_FREE(ace);
	}

	DIG_FREE(conf);
}

void
acl_conf_mgr_destroy(acl_conf_mgr_t* mgr)
{
	if (!mgr) return;

	acl_conf_mgr_iter_begin(mgr);
	while(mgr->iter_ptr) {
		acl_conf_t* ac = mgr->iter_ptr;
		mgr->iter_ptr = mgr->iter_ptr->next;

		acl_conf_destroy(ac);
	}

	DIG_FREE(mgr);
}

void
view_conf_destroy(view_conf_t* conf)
{
	if (!conf) return;
	
	view_conf_iter_begin(conf);
	while(conf->iter_ptr) {
		view_acl_t* va = conf->iter_ptr;
		conf->iter_ptr = conf->iter_ptr->next;

		DIG_FREE(va);
	}

	DIG_FREE(conf);
}

void
view_conf_mgr_destroy(view_conf_mgr_t* mgr)
{
	if (!mgr) return;

	view_conf_mgr_iter_begin(mgr);
	while(mgr->iter_ptr) {
		view_conf_t* vc = mgr->iter_ptr;
		mgr->iter_ptr = mgr->iter_ptr->next;

		view_conf_destroy(vc);
	}

	DIG_FREE(mgr);
}

void
smartdns_conf_destroy(smartdns_conf_t* conf)
{
	if (!conf) return;

	acl_conf_mgr_destroy(conf->acls);	
	view_conf_mgr_destroy(conf->views);

	DIG_FREE(conf);	
}

void
smartdns_conf_mgr_destroy(smartdns_conf_mgr_t* mgr)
{
	if (!mgr) return;

	smartdns_conf_mgr_iter_begin(mgr);
	while(mgr->iter_ptr) {
		smartdns_conf_t* sc = mgr->iter_ptr;
		mgr->iter_ptr = mgr->iter_ptr->next;

		smartdns_conf_destroy(sc);
	}

	DIG_FREE(mgr);
}

