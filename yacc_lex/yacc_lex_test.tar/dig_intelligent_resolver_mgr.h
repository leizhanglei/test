#ifndef _DIG_INTELLIGENT_RESOLVER_MGR_H_
#define _DIG_INTELLIGENT_RESOLVER_MGR_H_

#include <stdio.h>
#include <errno.h>

#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "dig_utils.h"
#include "dig_ip_tree.h"
#include "dig_rb_tree.h"
#include "dig_acl_conf.h"

#define DEFAULT_USER_NAME "system"
#define DEFAULT_ACL_NAME "match_any"
#define DEFAULT_ADDR "0.0.0.0"
#define DEFAULT_ADDR_MASK 0
#define DEFAULT_VIEW_NAME "default"
#define DEFAULT_VIEW_ID 0

#define USER_NAME_LEN 32
#define VIEW_NAME_LEN 32
#define VIEW_ID_LEN 6
#define ACL_NAME_LEN 32
#define IP_STR_LEN 32

struct conf_mgr;
typedef struct intelligent_resolver_mgr intelligent_resolver_mgr_t;
typedef struct rela_iptrees rela_iptrees_t;

result_t ir_mgr_create();
result_t init_ir_mgr_from_conf(struct conf_mgr* conf_mgr);
void ir_mgr_destroy();

uint16_t get_viewid_by_addr(const rela_iptrees_t* iptrees, const struct sockaddr* addr);
uint16_t get_viewid_by_viewname(const char* viewname);
char* get_viewname_by_viewid(uint16_t viewid);
rela_iptrees_t* get_iptrees_by_rela_name(const char* rela_name);

#endif

