#include <stdio.h>
#include <errno.h>

#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <stdarg.h>
#include <assert.h>
#include "dig_intelligent_resolver_mgr.h"
#include "dig_conf_mgr.h"

static intelligent_resolver_mgr_t* g_ir_mgr;

typedef struct viewmap_node {
	rbnode_t	view_key;
	uint16_t	view_id;
	char		view_name[VIEW_NAME_LEN];
} viewmap_node_t;

typedef struct iptreemap_node {
	rbnode_t	rela_key;
	ip_tree_t*	iptree;
} iptreemap_node_t;

struct intelligent_resolver_mgr
{
	rbtree_t*	iptreemap;
	rbtree_t*	viewmap; 
};

struct rela_iptrees
{
	ip_tree_t*	rela_iptree;	
	ip_tree_t*	sys_iptree;	
};

int 
compare_string(const void* string1, const void* string2)
{
	ASSERT(string1 && string2, "invalid parameters\n");
	return strcmp((const char*)string1, (const char*)string2);
}

static result_t
string_ip_to_h_ip(const char *str_ip, uint32_t *h_ip)
{
	in_addr_t n_addr = inet_addr(str_ip);
	if (INADDR_NONE == n_addr)
		return FAILED;

	*h_ip = ntohl((uint32_t)n_addr);
	return SUCCEED;
}

static result_t
addr_to_h_ip(const in_addr_t* addr, uint32_t *h_ip)
{
	if (INADDR_NONE == *addr)
		return FAILED;

	*h_ip = ntohl((uint32_t)(*addr));
	return SUCCEED;
}

result_t
ir_mgr_create()
{
	g_ir_mgr = NULL;
	DIG_MALLOC(g_ir_mgr, sizeof(intelligent_resolver_mgr_t));
	do {
		if (!g_ir_mgr)
			break;

		g_ir_mgr->iptreemap = rbtree_create(NULL, compare_string);
		if (g_ir_mgr->iptreemap == NULL)
			break;

		g_ir_mgr->viewmap = rbtree_create(NULL, compare_string);
		if (g_ir_mgr->viewmap == NULL)
			break;

		return SUCCEED;
	} while(0);

	ir_mgr_destroy();
	return FAILED;
}

void 
iptree_free(void* data, void* arg)
{
	free((int*)data);
}

void
ir_mgr_destroy()
{
	if (!g_ir_mgr)
		return;

	if (g_ir_mgr->iptreemap) {
		rbnode_t* tmp = rbtree_first(g_ir_mgr->iptreemap);
		while(tmp != RBTREE_NULL) {
			tmp = rbtree_delete(g_ir_mgr->iptreemap, tmp->key);
			if (tmp != RBTREE_NULL) {
				free((char*)(tmp->key));
				ip_tree_walk( ((iptreemap_node_t*)tmp)->iptree, iptree_free, NULL );
				free((iptreemap_node_t*)tmp);
			}
			tmp = rbtree_first(g_ir_mgr->iptreemap);
		}
		free(g_ir_mgr->iptreemap);
	}

	if (g_ir_mgr->viewmap) {
		rbnode_t* tmp = rbtree_first(g_ir_mgr->viewmap);
		while(tmp != RBTREE_NULL) {
			tmp = rbtree_delete(g_ir_mgr->viewmap, tmp->key);
			if (tmp != RBTREE_NULL) {
				free((char*)(tmp->key));
				free((viewmap_node_t*)tmp);
			}
			tmp = rbtree_first(g_ir_mgr->viewmap);
		}
		free(g_ir_mgr->viewmap);
	}

	free(g_ir_mgr);

	g_ir_mgr->iptreemap = NULL;
	g_ir_mgr->viewmap = NULL;
    g_ir_mgr = NULL;
}

static result_t 
add_viewid_to_viewmap(const char* name_key, uint32_t id_value)
{
	rbtree_t* viewmap = g_ir_mgr->viewmap;

	char* viewname = strdup(name_key);
	if (viewname == NULL)
		return FAILED;

    rbnode_t *node = rbtree_search(viewmap, (const void *)viewname);
    if (node) {
        printf("add duplicated view:%s\n", viewname);
        return FAILED;
    }

	viewmap_node_t* viewnode = NULL;
	DIG_MALLOC(viewnode, sizeof(viewmap_node_t));
	if (viewnode == NULL)
		return FAILED;

	viewnode->view_id = id_value;

	node = (rbnode_t*)viewnode;
	node->key = (const void*)viewname;

    rbnode_t* ret = rbtree_insert(viewmap, node, NULL);
	if (ret == NULL)
		return FAILED;

    return SUCCEED;
	
}

static result_t 
add_viewname_to_viewmap(uint32_t id_key, const char* name_value)
{
	rbtree_t* viewmap = g_ir_mgr->viewmap;

	char* str_viewid = NULL;
	DIG_MALLOC(str_viewid, VIEW_ID_LEN);
	if (str_viewid == NULL)
		return FAILED;

	memset(str_viewid, 0x00, VIEW_ID_LEN);
	sprintf(str_viewid, "%d", id_key);

    rbnode_t *node = rbtree_search(viewmap, (const void *)str_viewid);
    if (node) {
        printf("add duplicated view:%s\n", str_viewid);
        return FAILED;
    }

	viewmap_node_t* viewnode = NULL;
	DIG_MALLOC(viewnode, sizeof(viewmap_node_t));
	if (viewnode == NULL)
		return FAILED;

	strcpy(viewnode->view_name, name_value);

	node = (rbnode_t*)viewnode;
	node->key = (const void*)str_viewid;

    rbnode_t* ret = rbtree_insert(viewmap, node, NULL);
	if (ret == NULL)
		return FAILED;

    return SUCCEED;
	
}

uint16_t
get_viewid_by_addr(const rela_iptrees_t* iptrees, const struct sockaddr* addr)
{
	if (iptrees == NULL || addr == NULL)
		return -1;

	struct sockaddr_in* addr_in = (struct sockaddr_in*)addr;
	uint32_t h_ip;
	addr_to_h_ip(&addr_in->sin_addr.s_addr, &h_ip);


	if (iptrees->rela_iptree != NULL) {
		int* pvalue = ip_tree_find(iptrees->rela_iptree, h_ip);
		if (pvalue != NULL)
			return *pvalue;
	}
	if (iptrees->sys_iptree != NULL) {
		int* pvalue = ip_tree_find(iptrees->sys_iptree, h_ip);
		if (pvalue != NULL)
			return *pvalue;
	}

	return -1;
}

rela_iptrees_t*
get_iptrees_by_rela_name(const char* rela_name)
{
	if (!g_ir_mgr || !rela_name) 
		return NULL;

	rela_iptrees_t* iptrees = NULL;

	DIG_MALLOC(iptrees, sizeof(rela_iptrees_t));

	if (!iptrees)
		return NULL;

    rbnode_t *node = rbtree_search(g_ir_mgr->iptreemap, rela_name);
    if (node) {
		iptreemap_node_t* iptreemap_node = (iptreemap_node_t*)node;
		iptrees->rela_iptree = iptreemap_node->iptree;
    }
	node = rbtree_search(g_ir_mgr->iptreemap, DEFAULT_USER_NAME);

   	if (node) {
		iptreemap_node_t* iptreemap_node = (iptreemap_node_t*)node;
		iptrees->sys_iptree = iptreemap_node->iptree;
	}

	if (!iptrees->rela_iptree && !iptrees->sys_iptree) return NULL;

	return iptrees;
}

uint16_t
get_viewid_by_viewname(const char* viewname)
{
	if (!g_ir_mgr || !viewname)
		return -1;

    rbnode_t *node = rbtree_search(g_ir_mgr->viewmap, viewname);
    if (node) {
		viewmap_node_t* viewmap_node = (viewmap_node_t*)node;
        return viewmap_node->view_id;
    }
	return -1;
}

char*
get_viewname_by_viewid(uint16_t viewid)
{
	if (!g_ir_mgr)
		return NULL;

	char str_viewid[VIEW_ID_LEN];
	memset(str_viewid, 0x00, VIEW_ID_LEN);
	sprintf(str_viewid, "%d", viewid);

    rbnode_t *node = rbtree_search(g_ir_mgr->viewmap, str_viewid);
    if (node) {
		viewmap_node_t* viewmap_node = (viewmap_node_t*)node;
        return viewmap_node->view_name;
    }
	return NULL;
}

static result_t
add_ip_to_ip_tree(ip_tree_t* iptree, const char* ip, uint32_t mask, uint16_t viewid)
{
	uint32_t h_ip;
	result_t ret = string_ip_to_h_ip(ip, &h_ip);
	if (ret != SUCCEED) return FAILED;

	do {
		ret = ip_tree_check_insertable(iptree, h_ip, mask);
		if (ret == FAILED) {
			printf("may be different acl has the same ip, please check.\n");
			break;
		}

		int* id = malloc(sizeof(int));
		*id = viewid;
    	ret = ip_tree_insert_node(iptree, h_ip, mask, id);
		if (ret == FAILED)
			return FAILED;
	} while(0);

	return SUCCEED;
}

result_t
ir_mgr_add_ip_to_iptree(const char* rela_name, const char* ip, uint32_t mask, uint16_t viewid)
{
	iptreemap_node_t* iptree_map_node = NULL;

    rbnode_t *node = rbtree_search(g_ir_mgr->iptreemap, (const void *)rela_name);
    if (node) {
		iptree_map_node = (iptreemap_node_t*)node;
		result_t ret = add_ip_to_ip_tree(iptree_map_node->iptree, ip, mask, viewid);
		if (ret != SUCCEED) return FAILED;
    } else {

		DIG_MALLOC(iptree_map_node, sizeof(iptreemap_node_t));
		if (iptree_map_node == NULL)
			return FAILED;

		iptree_map_node->iptree = ip_tree_create(NULL);
		result_t ret = add_ip_to_ip_tree(iptree_map_node->iptree, ip, mask, viewid);
		if (ret != SUCCEED) return FAILED;

	
		node = (rbnode_t*)iptree_map_node;

		char* key_name = strdup(rela_name);
		if (!key_name) {
			DIG_FREE(iptree_map_node);
			return FAILED;
		}
		node->key = (const void*)key_name;

		rbtree_insert(g_ir_mgr->iptreemap, node, NULL);
	}

    return SUCCEED;
}

result_t
init_ir_mgr_by_default()
{
	result_t ret = add_viewname_to_viewmap(DEFAULT_VIEW_ID, DEFAULT_VIEW_NAME);
	if (ret != SUCCEED) return FAILED;

	ret = add_viewid_to_viewmap(DEFAULT_VIEW_NAME, DEFAULT_VIEW_ID);
	if (ret != SUCCEED) return FAILED;

	ret = ir_mgr_add_ip_to_iptree(DEFAULT_USER_NAME, DEFAULT_ADDR, DEFAULT_ADDR_MASK, DEFAULT_VIEW_ID);
	if (ret != SUCCEED) return FAILED;

	return SUCCEED;
}

result_t
init_ir_mgr_from_conf(struct conf_mgr* conf_mgr)
{
	result_t ret;
	if (!conf_mgr) {
		ret = init_ir_mgr_by_default();	
		if (ret != SUCCEED) return FAILED;
		else return SUCCEED;
	}

	smartdns_conf_mgr_t* smart_conf_mgr = get_smartdns_conf_mgr(conf_mgr);
	if (!smart_conf_mgr) {
		ret = init_ir_mgr_by_default();
		if (ret != SUCCEED) return FAILED;
		else return SUCCEED;
	}

	ret = smartdns_conf_mgr_iter_begin(smart_conf_mgr);
	if (ret != SUCCEED) return FAILED;

	smartdns_conf_t* smart_conf = smartdns_conf_mgr_iter_next(smart_conf_mgr);	
	while(smart_conf) {
		view_conf_mgr_t* view_conf_mgr = smartdns_conf_get_views(smart_conf);
		if (!view_conf_mgr) return FAILED;

		acl_conf_mgr_t* acl_conf_mgr = smartdns_conf_get_acls(smart_conf);
		if (!acl_conf_mgr) return FAILED;

		ret = view_conf_mgr_iter_begin(view_conf_mgr);
		if (ret != SUCCEED) return FAILED;

		view_conf_t* view_conf = view_conf_mgr_iter_next(view_conf_mgr);	
		while(view_conf) {
			if (!view_conf) return FAILED;

			ret = view_conf_iter_begin(view_conf);
			if (ret != SUCCEED) return FAILED;

			add_viewname_to_viewmap(view_conf->view_id, view_conf->view_name);
			add_viewid_to_viewmap(view_conf->view_name, view_conf->view_id);

			const char* view_acl_name = NULL;
			while(view_acl_name = view_conf_iter_next(view_conf)) {
				acl_conf_t* acl_conf = (acl_conf_t*)acl_conf_mgr_find_acl_by_name(acl_conf_mgr, view_acl_name);
				if (!acl_conf) return FAILED;

				ret = acl_conf_iter_begin(acl_conf);
				if (ret != SUCCEED) return FAILED;

				while(1) {
					const char* ip = NULL;
					uint32_t mask;
					ip = acl_conf_iter_next(acl_conf, &mask);

					if (!ip) break;

					ret = ir_mgr_add_ip_to_iptree(smart_conf->name, ip, mask, view_conf->view_id);
					if (ret != SUCCEED) return FAILED;
				}

			}
			
			view_conf = view_conf_mgr_iter_next(view_conf_mgr);	
		}

		smart_conf = smartdns_conf_mgr_iter_next(smart_conf_mgr);	
	}

	return SUCCEED;
}
