#ifndef _H_DIG_IP_TREE_H_
#define _H_DIG_IP_TREE_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "dig_error.h"

typedef struct ip_tree   ip_tree_t;
typedef void    (*value_del_function)(void *value);
typedef void    (*walk_function)(void *value, void *arg);

ip_tree_t *     ip_tree_create(value_del_function value_del_func);
void            ip_tree_delete(ip_tree_t *tree);
void            ip_tree_walk(ip_tree_t *tree, 
                        walk_function walk_func,
                        void *arg);
result_t        ip_tree_insert_node(ip_tree_t *tree,
                        uint32_t key, uint32_t mask, void *value);
result_t        ip_tree_check_insertable(ip_tree_t *tree,
                        uint32_t key, uint32_t mask);
result_t        ip_tree_delete_node(ip_tree_t *tree,
                        uint32_t key, uint32_t mask);
void *          ip_tree_find(ip_tree_t *tree, uint32_t key);

#endif /* _H_DIG_IP_TREE_H_ */
